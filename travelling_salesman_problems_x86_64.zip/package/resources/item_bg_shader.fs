#version 330

in vec2 fragTexCoord;
in vec4 fragColor;
out vec4 finalColor;

uniform sampler2D myTexture;
uniform int thickness;

void main() {
    vec2 size = 1.0 / textureSize(myTexture, 0);
    vec2 uv = fragTexCoord;
    uv -= 0.5;
    uv *= (1 + size * 4);
    uv += 0.5;

    vec4 aC = texture(myTexture, uv);
    if (aC.a > 0.1) {
        finalColor = mix(fragColor, aC, aC.a);
    } else {
        float alpha = 0.0;
        for (int x = -thickness; x <= thickness; x++)
        for (int y = -thickness; y <= thickness; y++)
        {
            alpha += texture(myTexture, uv + vec2(x, y) * size).a;
        }

        if (alpha > 0.01) {
            float outlineStrength = clamp(alpha, 0.0, 1.0);
            finalColor = vec4(fragColor.rgb, outlineStrength);
        }
    }
}
